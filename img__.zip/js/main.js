///////////////////////
/////// MAIN.js /////// 
///////////////////////

$(document).ready(function(){
    if ($(window).width() > 768) {
 
        $('.goal_item').click(function(){
            var col = $(this).attr('class');
            switch (col) {
                case "goal_item goal_1":
                    $('.goal_item').removeClass('active');
                    $('.goal_item.goal_1').addClass('active');
                    $('.goals').removeClass('active');
                    $('.g1').addClass('active');
                break;
                case "goal_item goal_2":
                    $('.goal_item').removeClass('active');
                    $('.goal_item.goal_2').addClass('active');
                    $('.goals').removeClass('active');
                    $('.g2').addClass('active');                
                break;
                case "goal_item goal_3":
                    $('.goal_item').removeClass('active');
                    $('.goal_item.goal_3').addClass('active'); 
                    $('.goals').removeClass('active');               
                    $('.g3').addClass('active');
                break;
                default:
                $('.goal_item').removeClass('active');
                $('.goal_item.goal_1').addClass('active');                
                $('.g1').addClass('active');
            } 
        })
    });
}

var swiper = new Swiper('.swiper-container', {
    pagination: {
      el: '.swiper-pagination',
    },
  });

